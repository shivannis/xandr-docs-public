package com.appnexus.data.lld.schemas.example;

import com.google.common.collect.ImmutableMap;
import com.google.protobuf.Message;
import org.apache.commons.cli.BasicParser;
import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.apache.commons.io.FileUtils;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.BytesWritable;
import org.apache.hadoop.io.SequenceFile;
import org.apache.hadoop.io.Writable;
import org.apache.hadoop.util.ReflectionUtils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.util.Map;
import java.util.zip.GZIPInputStream;

import static com.appnexus.data.lld.schemas.example.ProtobufUtils.ALLOWED_FORMATS;
import static com.appnexus.data.lld.schemas.example.ProtobufUtils.EXAMPLES_FOLDER;
import static com.appnexus.data.lld.schemas.example.ProtobufUtils.PROTOBUF_DELIMITED_FORMAT;
import static com.appnexus.data.lld.schemas.example.ProtobufUtils.PROTOBUF_FORMAT;

/**
 * This class reads protobuf data files from AppNexus and prints the fields to stdout. Supported schemas are in
 * src/main/proto and example data files are in src/main/resources/examples. You can specify which file to read with -i,
 * which schema to use with -s, and which format to read the file as with -f. When no file is specified, the example
 * protobuf sequence file corresponding to the schema is used. When no format is specified, protobuf sequence file is used.
 */
public class ProtobufReader {

    private static Map<String, String> formatToExtensionMap = ImmutableMap.of(
            PROTOBUF_DELIMITED_FORMAT, ".pb.gz",
            PROTOBUF_FORMAT, "");

    public static void main(String[] args) {

        final Options options = new Options();

        final Option schemaNameOpt = new Option("s", "schema", true, "schema to deserialize protobuf file");
        schemaNameOpt.setRequired(true);
        options.addOption(schemaNameOpt);

        final Option formatOpt = new Option("f", "format", true, "file format");
        formatOpt.setRequired(true);
        options.addOption(formatOpt);

        final Option inputOpt = new Option("i", "input", true, "input file path, defaults to example protobuf file for schema");
        inputOpt.setRequired(false);
        options.addOption(inputOpt);

        final CommandLineParser parser = new BasicParser();
        final HelpFormatter formatter = new HelpFormatter();
        final CommandLine cmd;

        try {
            cmd = parser.parse(options, args);
        } catch (ParseException e) {
            System.err.println(e.getMessage());
            formatter.printHelp(ProtobufReader.class.getCanonicalName(), options);
            System.exit(1);
            return;
        }

        final File dataFile;
        final String schema = cmd.getOptionValue("s");

        final Message defaultMsg;

        try {
            defaultMsg = ProtobufUtils.getDefaultMessageInstance(schema);
        } catch (RuntimeException e) {
            System.err.printf("Schema %s does not exist.\n", schema);
            System.exit(1);
            return;
        }

        final String format = cmd.getOptionValue("f");
        if (!ALLOWED_FORMATS.contains(format)) {
            System.err.printf("Format %s does not exist.\n", format);
        }

        try {
            if (cmd.hasOption(("i"))) {
                //Read from selected file.
                dataFile = new File(cmd.getOptionValue("i"));
            } else {
                //No input file selected. Use packaged example file, copied to a temp file.
                final File tmpFile = File.createTempFile("tmp_example", ".tmp");
                tmpFile.deleteOnExit();

                final String resourcePath = String.format("/%s/%s/%s%s", EXAMPLES_FOLDER, format, schema, formatToExtensionMap.get(format));
                final URL inputURL = ProtobufReader.class.getResource(resourcePath);
                // copy the resource to a temp file so it can be read as a SequenceFile
                FileUtils.copyURLToFile(inputURL, tmpFile);
                dataFile = tmpFile;
            }

            if (!dataFile.exists()) {
                System.err.printf("File %s does not exist.\n", dataFile.getPath());
                System.exit(1);
                return;
            }

            switch (format) {
                case PROTOBUF_FORMAT:
                    readProtobufFile(defaultMsg, dataFile);
                    break;
                case PROTOBUF_DELIMITED_FORMAT:
                    readProtobufDelimitedFile(defaultMsg, dataFile);
                    break;
                default:
                    System.exit(1);
            }
            System.out.println("Record(s) read successfully!");
        } catch (Exception e) {
            e.printStackTrace();
            System.exit(1);
        }
    }

    /**
     * Reads a protobuf sequence file and prints contents to stdout
     *
     * @param defaultMsg default instance of message type to read from file
     * @param file       file with protobuf data
     * @throws IOException i/o errors encountered when reading the file
     */
    private static void readProtobufFile(Message defaultMsg, File file) throws IOException {
        final Configuration conf = new Configuration();
        final Path p = new Path(file.getPath());

        try (final SequenceFile.Reader reader = new SequenceFile.Reader(conf, SequenceFile.Reader.file(p))) {
            final Writable key = (Writable) ReflectionUtils.newInstance(reader.getKeyClass(), conf);
            final BytesWritable value = new BytesWritable();

            while (reader.next(key, value)) {
                final Message.Builder b = defaultMsg.newBuilderForType();
                final Message m = b.mergeFrom(value.getBytes(), 0, value.getLength()).build();
                System.out.println(m);
            }
        }
    }

    /**
     * Reads a delimited protobuf file and prints contents to stdout
     *
     * @param defaultMsg default instance of message type to read from file
     * @param file       file with protobuf data
     * @throws IOException i/o errors encountered when reading the file
     */
    private static void readProtobufDelimitedFile(Message defaultMsg, File file) throws IOException {
        final InputStream input = new GZIPInputStream(new FileInputStream(file));
        Message m;
        while ((m = defaultMsg.getParserForType().parseDelimitedFrom(input)) != null) {
            System.out.println(m);
        }
    }
}
