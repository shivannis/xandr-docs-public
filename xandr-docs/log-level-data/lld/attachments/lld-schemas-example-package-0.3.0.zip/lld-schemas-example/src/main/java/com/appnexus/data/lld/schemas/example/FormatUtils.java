package com.appnexus.data.lld.schemas.example;

import com.google.common.base.CaseFormat;
import com.google.protobuf.Message;
import org.apache.avro.specific.SpecificRecord;

import java.lang.reflect.Method;
import java.util.Arrays;
import java.util.List;

/**
 * Util method getDefaultMessageInstance gets the default instance of a protobuf message according to the class name of
 * the message. It searches for generated proto classes in com.appnexus.lld then in com.appnexus.lld.lib, and throws a
 * ClassNotFoundException if the schema does not exist. Once the message class is found, it merely returns the
 * getDefaultInstance method of the GeneratedMessage class.
 */
class FormatUtils {
    static final String EXAMPLES_FOLDER = "examples";
    static final String PROTOBUF_FORMAT = "protobuf";
    static final String PROTOBUF_DELIMITED_FORMAT = "protobuf-delimited";
    static final String AVRO_FORMAT = "avro";

    static final List<String> ALLOWED_FORMATS = Arrays.asList(PROTOBUF_FORMAT, PROTOBUF_DELIMITED_FORMAT, AVRO_FORMAT);

    private static final String PROTOBUF_SCHEMA_PACKAGE = "com.appnexus.data.protobuf.generated";
    private static final String AVRO_SCHEMA_PACKAGE = "com.appnexus.data.avro.generated";

    static Message getDefaultMessageInstance(String messageClass) throws RuntimeException {
        try {
            Class<?> cls = getProtobufSchemaClass(messageClass);
            Method m = cls.getDeclaredMethod("getDefaultInstance");
            return (Message) m.invoke(null, (Object[]) null);
        } catch (Throwable e) {
            throw new RuntimeException(String.format("Failed to get default message object for %s", messageClass), e);
        }
    }

    private static Class<?> getProtobufSchemaClass(String feedName) throws ClassNotFoundException {
        final String schemaClassName = CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, feedName);
        final String fullClassName = String.format("%s.%s$%s", PROTOBUF_SCHEMA_PACKAGE, schemaClassName, feedName);
        return Class.forName(fullClassName);
    }

    @SuppressWarnings("unchecked")
    static Class<? extends SpecificRecord> getAvroSchemaClass(String feedName) throws ClassNotFoundException {
        final String feedPackageName = CaseFormat.LOWER_UNDERSCORE.to(CaseFormat.UPPER_CAMEL, feedName);
        final String fullClassName = String.format("%s.%s.%s", AVRO_SCHEMA_PACKAGE, feedPackageName, feedName);

        return (Class<? extends SpecificRecord>) Class.forName(fullClassName);
    }
}
