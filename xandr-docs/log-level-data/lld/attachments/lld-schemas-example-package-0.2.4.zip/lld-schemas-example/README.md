# AppNexus Cloud Export Protobuf Schemas

This project provides protobuf schemas as well as example code for:
- Generating Java classes
- Reading LLD files downloaded from AppNexus

You must first install `protoc` Then,

### Build the project
```bash
mvn clean install -Dprotoc=$(which protoc) -Dprotobuf.version="2.5.0"
```
**Warning:** Support for Protobuf versions other than 2.5.0 is considered to be experimental. Use with caution.

### Run example code
```bash
java -jar target/lld-schemas-example-combined.jar -s standard_feed -f protobuf
```
This command will read and print the standard_feed protobuf sequence example file at
src/main/resources/examples/protobuf/standard_feed.

### Read a file downloaded from AppNexus
**Note: Hadoop client with native Snappy support required. See AppNexus wiki for installation instructions.**
```bash
hadoop jar target/lld-schemas-example.jar com.appnexus.data.lld.schemas.example.ProtobufReader -s <schemaname> -f <format> -i <filename>
```
When no file is specified, example protobuf file corresponding to the schema and format is used. Example files are
located in src/main/resources/examples/.

If you see "Record(s) read successfully!", everything worked correctly.
