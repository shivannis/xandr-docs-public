# AppNexus Cloud Export Schemas

This project provides schemas as well as example code for:
- Generating Java classes
- Reading LLD files downloaded from AppNexus

Cloud Export supports the following formats*:
- `protobuf` Sequence files with protobuf message payloads.
- `protobuf-delimited` Length-delimited protobuf messages.
- `avro` Avro files written with the deflate codec. 

\* Additional information can be found on the AppNexus wiki.

To use this example project, you must first install `protoc`. Then,

### Build the project
```bash
mvn clean install -Dprotoc=$(which protoc) -Dprotobuf.version="2.5.0"
```
**Warning:** Support for Protobuf versions other than 2.5.0 is considered to be experimental. Use with caution.

### Run example code
```bash
# specified format (-f) can be one of "avro", "protobuf", or "protobuf-delimited"
java -jar target/lld-schemas-example-combined.jar -s standard_feed -f protobuf-delimited
```
This command will read and print the standard_feed protobuf-delimited example file at
`src/main/resources/examples/protobuf-delimited/standard_feed.pb.gz`.

### Read a file downloaded from AppNexus
**Note: Hadoop client with native Snappy support required. See AppNexus wiki for installation instructions.**
```bash
hadoop jar target/lld-schemas-example.jar com.appnexus.data.lld.schemas.example.CloudExportFileReader -s <schemaname> -f <format> -i <filename>
```
When no file is specified, example protobuf file corresponding to the schema and format is used. Example files are
located in `src/main/resources/examples/`.

If you see `Record(s) read successfully!`, everything worked correctly.